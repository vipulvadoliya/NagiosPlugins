===============
 WHAT
===============
This Nagios Plugin gets the size (Kb, Mb, Gb)  of the vmfs volumes (datastores) of a VMWare Server Esxi 4.x/5.x.

The VMWare VCLI must be installed and configured on the Nagios server (in my case, an Ubuntu server guest, inside the VMWare Server ESxi host), because we do use of the binary "vmkfstools" for getting the data.

Warning and critical levels can be set, and plugin gives us perfdata output too, so it can be graphed with graphical tools as pnp4nagios,  besides the usual Nagios states (OK, WARNING and CRITICAL).

============================
PREREQUISITES & INSTALLATION
============================

VMWare Esxi 4.x/5.x
-------------------

1) For the check_vmfs.sh plugin to work, it needs VMWare VCLI installed. You can get it for free, after registration, here:

https://my.vmware.com/web/vmware/details?downloadGroup=VSP510-VCLI-510&productId=285

2) Besides the standard commands of any Linux's flavours (grep, cut, cat, rm & awk) we need to install the bc application, which
is used to work with fractionnary numbers in unit conversion tasks. it's found in standard repositories so, in a debian based Linux
just type:

$ apt-get install bc

3) To check into the server automatically, we need the credentials of the VMWare ESXi servers stored in a single config file.
By default it could be stored in nagios plugin path:

/usr/local/nagios/libexec/vmware_esxi_conf.txt

and this txt file should have, at least, these fields:

# VMWARE_SERVER1 USER1 PASSWORD1
# VMWARE_SERVER2 USER2 PASSWORD2

This file should be, by security, in 600 mode, and owner and group of Nagios user.

By Example:
chown vmware_esxi_conf.txt
chmod 600 vmware_esxi_conf.txt

4) check_vmfs.sh is placed in plugins Nagios path=>/usr/local/nagios/libexec

5) Checking if nagios default path is /usr/local/nagios/var. Script needs to create a file there called check_vmfs.err to handle errors.
If Nagios is installed in other place, just change this line in script:
ERR_LOG=/usr/local/nagios/var/check_vmfs.err
to your default nagios installation directory.


===============
EXAMPLES
===============

Command line:
 * Checking datastore1 of server with IP 10.71.8.70 volume using configuration file stored in current directory, with a warning level of 75%, a critical level of 90% and used space in Gb
	$ check_vmfs.sh -C ./vmware_esxi_conf.txt -S 10.71.8.70 -V /vmfs/volumes/datastore1 -w 75 -c 90 -u Gb

it could give us results similar to these ones:
OK - /vmfs/volumes/datastore1 - total: 557.50 Gb - used: 230.03 Gb (41%)- free: 327.46 Gb (59%) | /vmfs/volumes/datastore1=230.03Gb;418.12;501.75;;557.50

Nagios example:
 1) Add to commands.cfg file (by default in /usr/local/nagios/etc/objects path):

	 define command{
		command_name check_vmfs
		command_line $USER1$/check_vmfs.sh -C $USER1$/$ARG1$ -S $ARG2$ -V $ARG3$ -w $ARG4$ -c $ARG5$ -u $ARG6$
	}

2) Add to vmware.cfg (or any other host with services, file):
	 define service{
          use                     generic-service
          host_name               svrvirtual
          service_description     datastore1 space
          check_command           check_vmfs!vmware_esxi_conf.txt!10.71.8.70!/vmfs/volumes/Sauron!80!90!Gb
  }

3) Reload nagios service
sudo /etc/init.d/nagios reload

4) Check everything is working!

===============
 CONTACT
===============
jpcozar@notforadsyahoo.es
Remove the *notforads* substring from the address.

===============
 LICENSE
===============
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
